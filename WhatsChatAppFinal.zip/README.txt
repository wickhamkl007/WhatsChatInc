Company Name: WhatsChatInc

Scrum Master: Kavin Wickham

Development Team: Taylor Powell & Blaze Wiseman

Github Repository: https://github.com/wickhamkl007/WhatsChatInc

Description of Project: A simple chat app with the ability for users to sign up for accounts and talk to other users in chatrooms with a user chosen topic. Within the chatroom the users will be able to communicate with text based messages. 
